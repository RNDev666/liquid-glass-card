# GitHub Profile

A Pen created on CodePen.

Original URL: [https://codepen.io/bezalel6/pen/EaZzdOP](https://codepen.io/bezalel6/pen/EaZzdOP).

THE liquid glass card for GITHUB Profile. 
Features: Drag;